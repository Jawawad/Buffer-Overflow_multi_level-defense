#! /usr/bin/env python
#  -*- coding: utf-8 -*-

import sys
import os
import subprocess
from Tkinter import *
import Tkinter, Tkconstants, tkFileDialog
import Tkinter
import tkMessageBox
import re
import paramiko



try:
    from Tkinter import *
except ImportError:
    from tkinter import *

try:
    import ttk
    py3 = False
except ImportError:
    import tkinter.ttk as ttk
    py3 = True

import BoF_Protection_support

def vp_start_gui():
    '''Starting point when module is the main routine.'''
    global val, w, root
    root = Tk()
    BoF_Protection_support.set_Tk_var()
    top = New_Toplevel (root)
    BoF_Protection_support.init(root, top)
    root.mainloop()

w = None
def create_New_Toplevel(root, *args, **kwargs):
    '''Starting point when module is imported by another program.'''
    global w, w_win, rt
    rt = root
    w = Toplevel (root)
    BoF_Protection_support.set_Tk_var()
    top = New_Toplevel (w)
    BoF_Protection_support.init(w, top, *args, **kwargs)
    return (w, top)

def destroy_New_Toplevel():
    global w
    w.destroy()
    w = None


class New_Toplevel:
    def __init__(self, top=None):
        '''This class configures and populates the toplevel window.
           top is the toplevel containing window.'''
        _bgcolor = '#d9d9d9'  # X11 color: 'gray85'
        _fgcolor = '#000000'  # X11 color: 'black'
        _compcolor = '#d9d9d9' # X11 color: 'gray85'
        _ana1color = '#d9d9d9' # X11 color: 'gray85' 
        _ana2color = '#d9d9d9' # X11 color: 'gray85' 
        self.style = ttk.Style()
        if sys.platform == "win32":
            self.style.theme_use('winnative')
        self.style.configure('.',background=_bgcolor)
        self.style.configure('.',foreground=_fgcolor)
        self.style.configure('.',font="TkDefaultFont")
        self.style.map('.',background=
            [('selected', _compcolor), ('active',_ana2color)])

        top.geometry("819x485+513+139")
        top.title("New Toplevel")
        top.configure(background="#d9d9d9")
        top.configure(highlightbackground="#d9d9d9")
        top.configure(highlightcolor="black")



        self.style.configure('TNotebook.Tab', background=_bgcolor)
        self.style.configure('TNotebook.Tab', foreground=_fgcolor)
        self.style.map('TNotebook.Tab', background=
            [('selected', _compcolor), ('active',_ana2color)])
        self.TNotebook1 = ttk.Notebook(top)
        self.TNotebook1.place(relx=0.01, rely=0.0, relheight=0.98, relwidth=0.99)

        self.TNotebook1.configure(width=714)
        self.TNotebook1.configure(takefocus="")
        self.TNotebook1_t0 = Frame(self.TNotebook1)
        self.TNotebook1.add(self.TNotebook1_t0, padding=3)
        self.TNotebook1.tab(0, text="System Status", compound="left"
                ,underline="-1", )

        self.TNotebook1_t1 = Frame(self.TNotebook1)
        self.TNotebook1.add(self.TNotebook1_t1, padding=3)
        self.TNotebook1.tab(1, text="OS Protection Level", compound="left"
                ,underline="-1", )

        self.TNotebook1_t2 = Frame(self.TNotebook1)
        self.TNotebook1.add(self.TNotebook1_t2, padding=3)
        self.TNotebook1.tab(2, text="Secure Programming", compound="none"
                ,underline="-1", )

        self.TNotebook1_t3 = Frame(self.TNotebook1)
        self.TNotebook1.add(self.TNotebook1_t3, padding=3)
        self.TNotebook1.tab(3, text="Gateway Security", compound="none"
                ,underline="-1", )

        self.TNotebook1_t4 = Frame(self.TNotebook1)
        self.TNotebook1.add(self.TNotebook1_t4, padding=3)
        self.TNotebook1.tab(4, text="Live detection", compound="none"
                ,underline="-1", )

        self.TNotebook1_t5 = Frame(self.TNotebook1)
        self.TNotebook1.add(self.TNotebook1_t5, padding=3)
        self.TNotebook1.tab(5, text="Defense Policy", compound="none"
                ,underline="-1", )

        self.TNotebook1_t6 = Frame(self.TNotebook1)
        self.TNotebook1.add(self.TNotebook1_t6, padding=3)
        self.TNotebook1.tab(6, text="About Program", compound="none"
                ,underline="-1", )
		
        self.TNotebook1_t6.configure(background="white")



        self.Button1 = Button(self.TNotebook1_t0)
        self.Button1.place(relx=0.08, rely=0.11, height=24, width=137)

        self.Button1.configure(pady="0")
        self.Button1.configure(text='''Discover Open Ports''')
	

        self.Button2 = Button(self.TNotebook1_t0)
        self.Button2.place(relx=0.35, rely=0.11, height=24, width=170)

        self.Button2.configure(pady="0")
        self.Button2.configure(text='''Discover OS bound ports''')

        self.Button3 = Button(self.TNotebook1_t0)
        self.Button3.place(relx=0.62, rely=0.11, height=24, width=260)

        self.Button3.configure(pady="0")
        self.Button3.configure(text='''Check in History for memory overflow''')

        self.Frame1 = Frame(self.TNotebook1_t0)
        self.Frame1.place(relx=0.06, rely=0.2, relheight=0.74, relwidth=0.88)
        self.Frame1.configure(relief=GROOVE)
        self.Frame1.configure(borderwidth="2")
        self.Frame1.configure(relief=GROOVE)

        self.Frame1.configure(width=625)

        self.Scrolledtext1 = ScrolledText(self.Frame1)
        self.Scrolledtext1.place(relx=0.0, rely=0.0, relheight=0.99
                , relwidth=1.1)
        self.Scrolledtext1.configure(font="TkTextFont")
        self.Scrolledtext1.configure(wrap=WORD)

        self.Label1 = Label(self.TNotebook1_t1)
        self.Label1.place(relx=-0.03, rely=0.0, height=31, width=244)

        self.Label1.configure(text='''Please define your OS type:''')


        self.Button4 = Button(self.TNotebook1_t1)
        self.Button4.place(relx=0.75, rely=0.1, height=24, width=107)

        self.Button4.configure(pady="0")
        self.Button4.configure(text='''Analyze''')

        self.Scrolledtext2 = ScrolledText(self.TNotebook1_t1)
        self.Scrolledtext2.place(relx=0.06, rely=0.27, relheight=0.47
                , relwidth=0.85)
        self.Scrolledtext2.configure(font="TkTextFont")
        self.Scrolledtext2.configure(width=10)
        self.Scrolledtext2.configure(wrap=NONE)

        self.Button5 = Button(self.TNotebook1_t1)
        self.Button5.place(relx=0.68, rely=0.84, height=34, width=157)

        self.Button5.configure(pady="0")
        self.Button5.configure(text='''Apply Protection state''')

        self.Label5 = Label(self.TNotebook1_t1)
        self.Label5.place(relx=0.04, rely=0.78, height=21, width=165)

        self.Label5.configure(text='''DEP Protection''')
        self.Label5.configure(width=165)

        self.Label6 = Label(self.TNotebook1_t1)
        self.Label6.place(relx=0.37, rely=0.78, height=21, width=141)

        self.Label6.configure(text='''ASLR Protection''')

        self.Radiobutton1 = Radiobutton(self.TNotebook1_t1)
        self.Radiobutton1.place(relx=0.03, rely=0.09, relheight=0.06
                , relwidth=0.14)
	os_var=StringVar()  

        self.Radiobutton1.configure(justify=LEFT)
        self.Radiobutton1.configure(text='''Linux''')
        self.Radiobutton1.configure(value="1")
	self.Radiobutton1.configure(variable=os_var)
	
	
        self.Radiobutton2 = Radiobutton(self.TNotebook1_t1)
        self.Radiobutton2.place(relx=0.24, rely=0.09, relheight=0.06
                , relwidth=0.17)

        self.Radiobutton2.configure(justify=LEFT)
        self.Radiobutton2.configure(text='''Windows''')
	self.Radiobutton2.configure(variable=os_var)
        self.Radiobutton2.configure(value="2")
	os_var.set(2)

        self.TCombobox1 = ttk.Combobox(self.TNotebook1_t1)
        self.TCombobox1.place(relx=0.08, rely=0.84, relheight=0.05
                , relwidth=0.15)
        self.value_list = ["Enable","Disable",]
        self.TCombobox1.configure(values=self.value_list)
        self.TCombobox1.configure(textvariable=BoF_Protection_support.dep_var)
        self.TCombobox1.configure(takefocus="")


        self.TCombobox2 = ttk.Combobox(self.TNotebook1_t1)
        self.TCombobox2.place(relx=0.39, rely=0.84, relheight=0.05
                , relwidth=0.15)
        self.value_list = ["Enable","Disable",]
        self.TCombobox2.configure(values=self.value_list)
        self.TCombobox2.configure(textvariable=BoF_Protection_support.aslr_var)
        self.TCombobox2.configure(takefocus="")

        self.Scrolledtext3 = ScrolledText(self.TNotebook1_t2)
        self.Scrolledtext3.place(relx=0.03, rely=0.09, relheight=0.56
                , relwidth=0.47)
        self.Scrolledtext3.configure(background="white")
        self.Scrolledtext3.configure(font="TkTextFont")

        self.Scrolledtext3.configure(width=10)
        self.Scrolledtext3.configure(wrap=NONE)

        self.Scrolledtext4 = ScrolledText(self.TNotebook1_t2)
        self.Scrolledtext4.place(relx=0.52, rely=0.09, relheight=0.56
                , relwidth=0.45)
        self.Scrolledtext4.configure(background="white")
        self.Scrolledtext4.configure(font="TkTextFont")

        self.Scrolledtext4.configure(width=10)
        self.Scrolledtext4.configure(wrap=NONE)

        self.Label3 = Label(self.TNotebook1_t2)
        self.Label3.place(relx=0.0, rely=0.0, height=31, width=234)

        self.Label3.configure(text='''Faulty source code view !!''')
        self.Label3.configure(width=234)
                

        self.Label4 = Label(self.TNotebook1_t2)
        self.Label4.place(relx=0.42, rely=0.02, height=21, width=267)

        self.Label4.configure(text='''Vulnerabilities!!''')
        self.Label4.configure(width=267)

        self.Label7 = Label(self.TNotebook1_t2)
        self.Label7.place(relx=0.01, rely=0.73, height=21, width=256)

        self.Label7.configure(text='''Please choose the faulty source code!!''')
        self.Label7.configure(width=256)

        self.Button6 = Button(self.TNotebook1_t2)
        self.Button6.place(relx=0.41, rely=0.71, height=24, width=77)

        self.Button6.configure(pady="0")
        self.Button6.configure(text='''Browse''')

        self.Button7 = Button(self.TNotebook1_t2)
        self.Button7.place(relx=0.63, rely=0.71, height=24, width=160)

        self.Button7.configure(pady="0")
        self.Button7.configure(text='''Find Vulnerability Areas''')

        self.Label8 = Label(self.TNotebook1_t2)
        self.Label8.place(relx=0.0, rely=0.8, height=21, width=688)

        self.Label8.configure(text='''Optimize the binary files security via integrating (stack canary) against stack based buffer overflow''')
        self.Label8.configure(width=588)

	file_path_var=StringVar()
        self.Entry2 = Entry(self.TNotebook1_t2)
        self.Entry2.place(relx=0.18, rely=0.89,height=20, relwidth=0.5)

        self.Entry2.configure(font="TkFixedFont")
 	self.Entry2.configure(textvariable=file_path_var)

        self.Label9 = Label(self.TNotebook1_t2)
        self.Label9.place(relx=0.04, rely=0.89, height=21, width=74)

        self.Label9.configure(anchor=W)

        self.Label9.configure(text='''Path to file:''')

        self.Button8 = Button(self.TNotebook1_t2)
        self.Button8.place(relx=0.72, rely=0.89, height=24, width=86)

        self.Button8.configure(pady="0")
        self.Button8.configure(text='''Compile''')

        self.Label10 = Label(self.TNotebook1_t3)
        self.Label10.place(relx=-0.03, rely=0.07, height=21, width=220)

        self.Label10.configure(text='''IP Address of Gateway:''')
        self.Label10.configure(width=194)

	ip_addr_var=StringVar()

        self.Entry3 = Entry(self.TNotebook1_t3)
        self.Entry3.place(relx=0.31, rely=0.07,height=20, relwidth=0.37)

        self.Entry3.configure(font="TkFixedFont")
        self.Entry3.configure(textvariable=ip_addr_var)


        self.Button9 = Button(self.TNotebook1_t3)
        self.Button9.place(relx=0.75, rely=0.07, height=24, width=93)

        self.Button9.configure(pady="0")
        self.Button9.configure(text='''Test''')

        self.Label11 = Label(self.TNotebook1_t3)
        self.Label11.place(relx=0.01, rely=0.16, height=21, width=47)

        self.Label11.configure(anchor=W)

        self.Label11.configure(text='''Output:''')

        self.Scrolledtext5 = ScrolledText(self.TNotebook1_t3)
        self.Scrolledtext5.place(relx=0.03, rely=0.22, relheight=0.36
                , relwidth=0.92)
        self.Scrolledtext5.configure(background="white")
        self.Scrolledtext5.configure(font="TkTextFont")

        self.Scrolledtext5.configure(insertborderwidth="3")

        self.Scrolledtext5.configure(width=10)
        self.Scrolledtext5.configure(wrap=NONE)

        self.Label12 = Label(self.TNotebook1_t3)
        self.Label12.place(relx=-0.02, rely=0.6, height=21, width=200)

        self.Label12.configure(text=''' Recommended Patch ''')
        self.Label12.configure(width=378)
	"""
        self.Scrolledtext6 = ScrolledText(self.TNotebook1_t3)
        self.Scrolledtext6.place(relx=0.03, rely=0.67, relheight=0.29
                , relwidth=0.93)
        self.Scrolledtext6.configure(insertborderwidth="3")

        self.Scrolledtext6.configure(width=10)
        self.Scrolledtext6.configure(wrap=NONE)
	"""
	patch_var=IntVar()  
	self.Patch1 = Radiobutton(self.TNotebook1_t3)
	self.Patch1.place(relx=0.04, rely=0.67, relheight=0.06, relwidth=0.80)

	self.Patch1.configure(text='''Update your RouterOS to the last version or Bugfix version''')
	self.Patch1.configure(value=1)
	#self.Patch1.configure(textvariable=patch_var)
	self.Patch1.configure(variable=patch_var)
	self.Patch1.configure(justify=LEFT)
	self.Patch1.configure(anchor=W)

	self.Patch2 = Radiobutton(self.TNotebook1_t3)
	self.Patch2.place(relx=0.04, rely=0.75, relheight=0.06, relwidth=0.80)
	self.Patch2.configure(value=2)
	#self.Patch2.configure(textvariable=patch_var)
	self.Patch2.configure(variable=patch_var)	
	self.Patch2.configure(justify=LEFT)
	self.Patch2.configure(text='''Do not use Winbox and disable it''')
	self.Patch2.configure(anchor=W)

		
	self.Patch3 = Radiobutton(self.TNotebook1_t3)
	self.Patch3.place(relx=0.04, rely=0.83, relheight=0.06, relwidth=0.80)
	self.Patch3.configure(value=3)
	#self.Patch3.configure(textvariable=patch_var)
	self.Patch3.configure(variable=patch_var)	
	self.Patch3.configure(justify=LEFT)
	self.Patch3.configure(text='''Dedicate only access to admin and deny anonymous accesses to Router''')
	self.Patch3.configure(anchor=W)
	self.admin_ip = Entry(self.TNotebook1_t3)
	
	self.patch_btn = Button(self.TNotebook1_t3)
        self.patch_btn.place(relx=0.07, rely=0.92,height=24, width=157)

        self.patch_btn.configure(pady="0")
        self.patch_btn.configure(text='''Apply Patch''')
	
	admin_ip_addr=StringVar()
    	self.admin_ip.place(relx=0.7, rely=0.83,height=20, relwidth=0.20)

    	self.admin_ip.configure(font="TkFixedFont")
    	self.admin_ip.configure(textvariable=admin_ip_addr)
		
        self.Label20 = Label(self.TNotebook1_t4)
        self.Label20.place(relx=0.04, rely=0.07, height=21, width=104)

        self.Label20.configure(text='''Incidents:''')

        self.Scrolledtext7 = ScrolledText(self.TNotebook1_t4)
        self.Scrolledtext7.place(relx=0.08, rely=0.13, relheight=0.36
                , relwidth=0.86)

        self.Scrolledtext7.configure(font="TkTextFont")

        self.Scrolledtext7.configure(width=10)
        self.Scrolledtext7.configure(wrap=NONE)

        self.Label21 = Label(self.TNotebook1_t4)
        self.Label21.place(relx=0.0, rely=0.56, height=21, width=235)

        self.Label21.configure(text='''Adding new signature:''')
        self.Label21.configure(width=235)

        self.Label22 = Label(self.TNotebook1_t4)
        self.Label22.place(relx=0.04, rely=0.62, height=21, width=115)

        self.Label22.configure(text='''Source IP''')
        self.Label22.configure(width=115)

        self.Label23 = Label(self.TNotebook1_t4)
        self.Label23.place(relx=0.04, rely=0.69, height=21, width=139)

        self.Label23.configure(text='''Destination IP''')
        self.Label23.configure(width=139)

        self.Entry6 = Entry(self.TNotebook1_t4)
        self.Entry6.place(relx=0.25, rely=0.62,height=20, relwidth=0.23)

        self.Entry6.configure(font="TkFixedFont")

        self.Entry7 = Entry(self.TNotebook1_t4)
        self.Entry7.place(relx=0.25, rely=0.69,height=20, relwidth=0.23)

        self.Entry7.configure(font="TkFixedFont")


        self.Label24 = Label(self.TNotebook1_t4)
        self.Label24.place(relx=0.48, rely=0.62, height=21, width=137)

        self.Label24.configure(highlightcolor="black")
        self.Label24.configure(text='''Source Port #''')
        self.Label24.configure(width=137)

        self.Label25 = Label(self.TNotebook1_t4)
        self.Label25.place(relx=0.49, rely=0.69, height=21, width=141)

        self.Label25.configure(text='''Destination Port #''')
        self.Label25.configure(width=141)

        self.Entry8 = Entry(self.TNotebook1_t4)
        self.Entry8.place(relx=0.7, rely=0.62,height=20, relwidth=0.23)

        self.Entry8.configure(font="TkFixedFont")


        self.Entry9 = Entry(self.TNotebook1_t4)
        self.Entry9.place(relx=0.7, rely=0.69,height=20, relwidth=0.23)

        self.Entry9.configure(font="TkFixedFont")

        self.Label26 = Label(self.TNotebook1_t4)
        self.Label26.place(relx=0.04, rely=0.76, height=21, width=115)

        self.Label26.configure(text='''Message:''')
        self.Label26.configure(width=115)

        self.Entry10 = Entry(self.TNotebook1_t4)
        self.Entry10.place(relx=0.25, rely=0.76,height=20, relwidth=0.23)

        self.Entry10.configure(font="TkFixedFont")

        self.Label27 = Label(self.TNotebook1_t4)
        self.Label27.place(relx=0.04, rely=0.82, height=21, width=109)

        self.Label27.configure(text='''Content''')
        self.Label27.configure(width=109)

        self.Entry11 = Entry(self.TNotebook1_t4)
        self.Entry11.place(relx=0.25, rely=0.82,height=20, relwidth=0.23)

        self.Entry11.configure(font="TkFixedFont")


        self.Label28 = Label(self.TNotebook1_t4)
        self.Label28.place(relx=0.48, rely=0.76, height=21, width=101)

        self.Label28.configure(text='''Depth:''')
        self.Label28.configure(width=101)

        self.Entry12 = Entry(self.TNotebook1_t4)
        self.Entry12.place(relx=0.7, rely=0.76,height=20, relwidth=0.23)

        self.Entry12.configure(font="TkFixedFont")

        self.Label29 = Label(self.TNotebook1_t4)
        self.Label29.place(relx=0.49, rely=0.82, height=21, width=105)

        self.Label29.configure(text='''Class Type:''')
        self.Label29.configure(width=105)

        self.Entry13 = Entry(self.TNotebook1_t4)
        self.Entry13.place(relx=0.7, rely=0.82,height=20, relwidth=0.23)
        self.Entry13.configure(background="white")
        self.Entry13.configure(disabledforeground="#a3a3a3")
        self.Entry13.configure(font="TkFixedFont")


        self.Label30 = Label(self.TNotebook1_t4)
        self.Label30.place(relx=0.04, rely=0.89, height=21, width=82)

        self.Label30.configure(text='''Sid''')
        self.Label30.configure(width=82)

        self.Entry14 = Entry(self.TNotebook1_t4)
        self.Entry14.place(relx=0.25, rely=0.89,height=20, relwidth=0.23)
        self.Entry14.configure(font="TkFixedFont")
 
        self.Button11 = Button(self.TNotebook1_t4)
        self.Button11.place(relx=0.72, rely=0.91, height=24, width=157)

        self.Button11.configure(pady="0")
        self.Button11.configure(text='''Add Signature''')

        self.Button12 = Button(self.TNotebook1_t4)
        self.Button12.place(relx=0.72, rely=0.51, height=24, width=157)

        self.Button12.configure(pady="0")
        self.Button12.configure(text='''Reload Incidents''')


        self.Label15 = Label(self.TNotebook1_t5)
        self.Label15.place(relx=0.13, rely=0.13, height=21, width=131)
        self.Label15.configure(text='''Source Address''')
        self.Label15.configure(width=131)
	
	fw_src_addr=StringVar()

        self.Entry4 = Entry(self.TNotebook1_t5)
        self.Entry4.place(relx=0.30, rely=0.13,height=20, relwidth=0.14)

        self.Entry4.configure(font="TkFixedFont")
        self.Entry4.configure(textvariable=fw_src_addr)

        self.Label16 = Label(self.TNotebook1_t5)
        self.Label16.place(relx=0.118, rely=0.20, height=21, width=125)
        self.Label16.configure(text='''Source Port''')
        self.Label16.configure(width=125)


	fw_src_port=StringVar()

        self.Entry5 = Entry(self.TNotebook1_t5)
        self.Entry5.place(relx=0.30, rely=0.20,height=20, relwidth=0.14)
        self.Entry5.configure(font="TkFixedFont")
        self.Entry5.configure(textvariable=fw_src_port)
		#-----------------------------------
		
	self.Label15_2 = Label(self.TNotebook1_t5)
        self.Label15_2.place(relx=0.47, rely=0.13, height=21, width=131)
        self.Label15_2.configure(text='''Destination Address''')
        self.Label15_2.configure(width=131)
	
	fw_dst_addr=StringVar()

        self.Entry4_2 = Entry(self.TNotebook1_t5)
        self.Entry4_2.place(relx=0.66, rely=0.13,height=20, relwidth=0.14)

        self.Entry4_2.configure(font="TkFixedFont")
        self.Entry4_2.configure(textvariable=fw_dst_addr)

        self.Label16_2 = Label(self.TNotebook1_t5)
        self.Label16_2.place(relx=0.455, rely=0.20, height=21, width=125)
        self.Label16_2.configure(text='''Destination Port''')
        self.Label16_2.configure(width=125)


	fw_dst_port=StringVar()

        self.Entry5_2 = Entry(self.TNotebook1_t5)
        self.Entry5_2.place(relx=0.66, rely=0.20,height=20, relwidth=0.14)
        self.Entry5_2.configure(font="TkFixedFont")
        self.Entry5_2.configure(textvariable=fw_dst_port)
		
		#-----------------------------------
        self.Label17 = Label(self.TNotebook1_t5)
        self.Label17.place(relx=0.1, rely=0.28, height=21, width=131)

        self.Label17.configure(text='''Protocol''')
        self.Label17.configure(width=131)

        self.Label18 = Label(self.TNotebook1_t5)
        self.Label18.place(relx=0.07, rely=0.04, height=21, width=174)
        self.Label18.configure(anchor=W)

        self.Label18.configure(text='''Define Firewall behavior !''')

        self.Radiobutton7 = Radiobutton(self.TNotebook1_t5)
        self.Radiobutton7.place(relx=0.41, rely=0.28, relheight=0.06
                , relwidth=0.07)

	fw_protocol=StringVar();
        self.Radiobutton7.configure(justify=LEFT)
        self.Radiobutton7.configure(text='''TCP''')
        self.Radiobutton7.configure(value="tcp")
        self.Radiobutton7.configure(variable=fw_protocol)

        self.Radiobutton8 = Radiobutton(self.TNotebook1_t5)
        self.Radiobutton8.place(relx=0.59, rely=0.28, relheight=0.06
                , relwidth=0.07)

        self.Radiobutton8.configure(justify=LEFT)
        self.Radiobutton8.configure(text='''UDP''')
        self.Radiobutton8.configure(value="udp")
	    
        self.Radiobutton8.configure(variable=fw_protocol)

        self.Label19 = Label(self.TNotebook1_t5)
        self.Label19.place(relx=0.1, rely=0.36, height=21, width=121)

        self.Label19.configure(text='''Action''')
        self.Label19.configure(width=121)

        self.Button10 = Button(self.TNotebook1_t5)
        self.Button10.place(relx=0.70, rely=0.34, height=30, width=100)
        self.Button10.configure(activebackground="#d9d9d9")
        self.Button10.configure(activeforeground="#000000")
        self.Button10.configure(background="#91d861")
        self.Button10.configure(disabledforeground="#a3a3a3")
        self.Button10.configure(foreground="#000000")
        self.Button10.configure(highlightbackground="#d9d9d9")
        self.Button10.configure(highlightcolor="black")
        self.Button10.configure(pady="0")
        self.Button10.configure(text='''Add Rule''')
        
        self.Button11 = Button(self.TNotebook1_t5)
        self.Button11.place(relx=0.70, rely=0.41, height=30, width=100)
        self.Button11.configure(activebackground="#d9d9d9")
        self.Button11.configure(activeforeground="#000000")
        self.Button11.configure(background="#d82400")
        self.Button11.configure(disabledforeground="#a3a3a3")
        self.Button11.configure(foreground="#000000")
        self.Button11.configure(highlightbackground="#d9d9d9")
        self.Button11.configure(highlightcolor="black")
        self.Button11.configure(pady="0")
        self.Button11.configure(text='''Remove Rule''') 
        
        self.Button12 = Button(self.TNotebook1_t5)
        self.Button12.place(relx=0.70, rely=0.48, height=30, width=144)
        self.Button12.configure(activebackground="#d9d9d9")
        self.Button12.configure(activeforeground="#000000")
        self.Button12.configure(background="#c6d823")
        self.Button12.configure(disabledforeground="#a3a3a3")
        self.Button12.configure(foreground="#000000")
        self.Button12.configure(highlightbackground="#d9d9d9")
        self.Button12.configure(highlightcolor="black")
        self.Button12.configure(pady="0")
        self.Button12.configure(text='''Make rule persistent''')
        

        self.TCombobox3 = ttk.Combobox(self.TNotebook1_t5)
        self.TCombobox3.place(relx=0.30, rely=0.36, relheight=0.05, relwidth=0.15)

        self.value_list = ["ACCEPT","DROP",]
        self.TCombobox3.configure(values=self.value_list)
        self.TCombobox3.configure(textvariable=BoF_Protection_support.defense_action_var)
        self.TCombobox3.configure(takefocus="")
        
        self.TCombobox4 = ttk.Combobox(self.TNotebook1_t5)
        self.TCombobox4.place(relx=0.30, rely=0.44, relheight=0.05, relwidth=0.15)
        self.value_list_2 = ["INPUT","OUTPUT","FORWARD"]
        self.TCombobox4.configure(values=self.value_list_2)
        chain_var=StringVar();
        self.TCombobox4.configure(textvariable=chain_var)
        self.TCombobox4.configure(takefocus="")

        self.Label19 = Label(self.TNotebook1_t5)
        self.Label19.place(relx=0.1, rely=0.44, height=21, width=121)

        self.Label19.configure(text='''Chain''')
        self.Label19.configure(width=121)
       
        self.Label20 = Label(self.TNotebook1_t5)
        self.Label20.place(relx=0.0, rely=0.53, height=21, width=200)

        self.Label20.configure(text=''' Rules Preview ''')
        self.Label20.configure(width=378)

        self.Scrolledtext8 = ScrolledText(self.TNotebook1_t5)
        self.Scrolledtext8.place(relx=0.06, rely=0.60, relheight=0.29
                , relwidth=0.84)
        self.Scrolledtext8.configure(insertborderwidth="3")

        self.Scrolledtext8.configure(width=10)
        self.Scrolledtext8.configure(wrap=NONE)
       
        self.Button22 = Button(self.TNotebook1_t5)
        self.Button22.place(relx=0.70, rely=0.90, height=30, width=100)
        self.Button22.configure(pady="0")
        self.Button22.configure(text='''LIst Rules''')
       
        self.Label13 = Label(self.TNotebook1_t6)
        self.Label13.place(relx=0.23, rely=0.04, height=241, width=440)
        self.Label13.configure(anchor=N)
        self.Label13.configure(text='''
This pogram is developed for  managing 
countermeasure or reduction of buffer overflow 
attack. This program issued its first use on JRS 
organization. it was used for research purpose.
Requirements of Program;
-using Linux OS: (tested on Xubuntu 18.04)
-having python version 2.7 and 3.5 installed
-having snort IDS installed and configured.
Developer info:
Name:     Muhammad Jawad Sikandary
email:    Sikandaryj@gmail.com
contact:  (0093)797080283
Senior student of Computer Science Faculty 
of Herat University
''')
	
			
	
        self.Label13.configure(width=500)
        self.Label13.configure(background="white")


        self.Label14 = Label(self.TNotebook1_t6)
        self.Label14.place(relx=0.45, rely=0.68, height=130, width=90)
        self.Label14.configure(activebackground="#f9f9f9")
        self.Label14.configure(activeforeground="black")
        self.Label14.configure(background="white")
        self.Label14.configure(disabledforeground="#a3a3a3")
        self.Label14.configure(foreground="#000000")
        self.Label14.configure(highlightbackground="#d9d9d9")
        self.Label14.configure(highlightcolor="black")
        self._img1 = PhotoImage(file="./a.png")
        self.Label14.configure(image=self._img1)
        self.Label14.configure(text='''Label''')



	self.Label15 = Label(self.TNotebook1_t6)
        self.Label15.place(relx=0.05, rely=0.0, height=150, width=120)
        self.Label15.configure(background="white")
      
        self._img2 = PhotoImage(file="./red.gif")
        self.Label15.configure(image=self._img2)
        self.Label15.configure(background="white")

	self.Label16 = Label(self.TNotebook1_t6)
        self.Label16.place(relx=0.80, rely=0.0, height=150, width=120)
        self.Label16.configure(background="white")
      
        self._img3 = PhotoImage(file="./blue.gif")
        self.Label16.configure(image=self._img3)


	def open_ports():
		#open_ports_cmd=os.system("netstat -lntu | grep LISTEN")
		open_ports_cmd=os.popen("netstat -lntu | grep LISTEN").read()
		print(open_ports_cmd)
		self.Scrolledtext1.delete('1.0', END)
		self.Scrolledtext1.insert(END,'\n'+""+open_ports_cmd)
	self.Button1.configure(command=open_ports)

	def os_ports():
		
		os_ports_cmd=os.popen("netstat -ntua").read()
		print(os_ports_cmd)
		self.Scrolledtext1.delete('1.0', END)
		self.Scrolledtext1.insert(END,'\n'+""+os_ports_cmd)
	self.Button2.configure(command=os_ports)	

	def find(substr, infile, outfile):
		with open(infile) as a, open(outfile, 'w') as b:
	   		for line in a:
	    			if substr in line:
	     				b.write(line + '\n')
 

	find('segfault', '/var/log/kern.log', '/home/jawad/Desktop/gui_app/segfault_events.txt')
	
	def check_history():
		find('segfault', '/var/log/kern.log', '/home/jawad/Desktop/gui_app/segfault_events.txt')
		event_details=os.popen("cat /home/jawad/Desktop/gui_app/segfault_events.txt").read()
		self.Scrolledtext1.delete('1.0', END)
		self.Scrolledtext1.insert(END,'\n'+""+event_details)				
	self.Button3.configure(command=check_history)	
	
	def os_select():
		os_aslr2=os.popen(""" cat /proc/sys/kernel/randomize_va_space""").read()
		os_value=os_var.get()
		os_dep=os.popen(""" dmesg | grep "NX (Execute Disable)" """).read()
		

		os_aslr=re.findall(r".",os_aslr2)
		os_aslr=str(os_aslr[0])
		print("os value is:"+os_value)
		print("aslr :"+os_aslr)
		if os_value=="1":
			if os_aslr=="2":
				print("aslr is:  "+os_aslr)
				self.Scrolledtext2.delete('1.0', END)
				self.Scrolledtext2.insert(END," ASLR (Address Space Layout Randomization) : enabled")
				self.Scrolledtext2.insert(END,"\n"+os_dep)
			elif os_aslr=="0":
				print("aslr is:  "+os_aslr)
				self.Scrolledtext2.delete('1.0', END)
				self.Scrolledtext2.insert(END," ASLR (Address Space Layout Randomization) : disabled")
				self.Scrolledtext2.insert(END,"\n"+os_dep)
		elif os_value=="2":
			self.Scrolledtext2.delete('1.0', END)
			self.Scrolledtext2.insert(END," Not configured Yet on windows")
	self.Button4.configure(command=os_select)
	
	def btnaction_apply_protection_state():
		aslr_state=str(BoF_Protection_support.aslr_var.get())
		print(aslr_state)
		if aslr_state=="Enable":
			print("dakhel Enable")
			os.popen("""echo "2" > /proc/sys/kernel/randomize_va_space""").read()		
		else:
			os.popen("""echo "0" > /proc/sys/kernel/randomize_va_space""").read()
		print("aslr after combobox:  "+str(os.popen("""cat /proc/sys/kernel/randomize_va_space""").read()))
	self.Button5.configure(command=btnaction_apply_protection_state)
	
	def file_chooser():

		#root = Tk()
		root.filename = tkFileDialog.askopenfilename(initialdir = "/home/jawad/Desktop",title = "Select file",filetypes = (("Python script","*.py"),("C source file","*.c"),("text files","*.txt"),("all files","*.*")))
		file_path=root.filename
		file=open(file_path,"r")
		content=file.read()
		self.Scrolledtext3.delete('1.0', END)
		self.Scrolledtext3.insert(END,content)
		file_path_var.set(file_path)
		print (root.filename)
	self.Button6.configure(command=file_chooser)


	def find_vulnerability():

		path=file_path_var.get()
		vuln_line=[]
		function=["strcpy","strcat","sprintf","gets","lstrcpy","lstrcat"]
		j=0
		output=[]
		for i in function:
			print(function[j])
			res=os.popen("""cat """ +path+""" | grep """+function[j]).read()
			if res<>"":			
				output.append(res)
			j=j+1	
		for a in output:
			print(a)		
			self.Scrolledtext4.delete('1.0', END)
			self.Scrolledtext4.insert(END,"\n"+a)

	self.Button7.configure(command=find_vulnerability)
	
	def compile_canary():
		inputFilepath = file_path_var.get()
		filename_ext = os.path.basename(inputFilepath)
		filename, file_extension = os.path.splitext(filename_ext)

		print(filename+"\n"+file_extension)
		abs_path=os.path.dirname(inputFilepath)
		print(abs_path)
		os.chdir(abs_path)

		p=os.popen("""gcc """+ inputFilepath+""" -o """+filename+""" -fstack-protector-strong""").read()			
		print(p)		
		os.chdir(abs_path)
		tkMessageBox.showinfo("compilation", "Compiled Successfully!")
	self.Button8.configure(command=compile_canary)

	def test_gateway():
		ip=ip_addr_var.get();
		creds=os.popen("""python3 WinboxExploit.py """+ip).read()	
		p=creds.replace(" ", "")

		if p!="":	
			self.Scrolledtext5.delete('1.0', END)
			self.Scrolledtext5.insert(END,"\n"+creds)
			
			suggest="""1.\tUpgrade the router to a RouterOS version up to 6.43
			\n2.\tDisable the WinBox service on the router.
			\n3.\t/ip firewall filter add chain=input in-interface=wan protocol=tcp dst-port=8291 action=drop.
			\n4.\t/tool mac-server mac-winbox.
			"""
			#self.Scrolledtext6.delete('1.0', END)
			#self.Scrolledtext6.insert(END,"\n"+suggest)
			
	self.Button9.configure(command=test_gateway)
		
	def add_rule():
		
		rule="iptables -A"
		src_ip=fw_src_addr.get()
		src_port=fw_src_port.get()
		dst_ip=fw_dst_addr.get()
		dst_port=fw_dst_port.get()
		protocol=fw_protocol.get()
		action=BoF_Protection_support.defense_action_var.get()
		chaine=chain_var.get()
		
		if chaine !="":
			rule += " "+chaine+" "
		else:
			chaine="INPUT"
			rule += " "+chaine+" "
		print("rule after chain:\t"+rule)
		
		if src_ip !="":
			rule += " -s "+src_ip+" "
		print("rule after src ip:\t"+rule)
		
		if src_port !="" and protocol !="" and dst_port =="":
			rule += " -p "+protocol+" "			
			rule += " --sport "+src_port+" "
		elif src_port !="" and protocol =="" and dst_port =="":
			protocol="tcp"
			rule += " -p "+protocol+" "
			rule += " --sport "+src_port+" "
		print("rule after src port:\t"+rule)
		
		if dst_ip !="":
			rule += " -d "+dst_ip+" "
		print("rule after dst ip:\t"+rule)
		
		if dst_port !="" and protocol !="" and src_port =="":
			rule += " -p "+protocol+" "
			rule += " --dport "+dst_port+" "
		elif dst_port !="" and protocol =="" and src_port =="":
			protocol="tcp"
			rule += " -p "+protocol+" "
			rule += " --dport "+dst_port+" "
		print("rule after dst port:\t"+rule)
		
		
		if action !="":
			rule += " -j "+action+" "
		else:
			action="ACCEPT"
			rule += " "+action+" "
		print("rule after chain:\t"+rule)
		
		print("add rule:\n"+"source ip: " + src_ip+"\n"+"source port:"+src_port+"\nDestination ip: " + dst_ip+"\n"+"Destination port:"+dst_port+"\n"+"protocol:"+protocol+"\n"+"Action:"+action+"\n"+"Chain:"+chaine)
		
		creds=os.popen(rule).read()	

	
	
	self.Button10.configure(command=add_rule)
	
	
	
	def delete_rule():
		
		rule="iptables -D"
		src_ip=fw_src_addr.get()
		src_port=fw_src_port.get()
		dst_ip=fw_dst_addr.get()
		dst_port=fw_dst_port.get()
		protocol=fw_protocol.get()
		action=BoF_Protection_support.defense_action_var.get()
		chaine=chain_var.get()
		
		if chaine !="":
			rule += " "+chaine+" "
		else:
			chaine="INPUT"
			rule += " "+chaine+" "
		print("rule after chain:\t"+rule)
		
		if src_ip !="":
			rule += " -s "+src_ip+" "
		print("rule after src ip:\t"+rule)
		
		if src_port !="" and protocol !="" and dst_port =="":
			rule += " -p "+protocol+" "			
			rule += " --sport "+src_port+" "
		elif src_port !="" and protocol =="" and dst_port =="":
			protocol="tcp"
			rule += " -p "+protocol+" "
			rule += " --sport "+src_port+" "
		print("rule after src port:\t"+rule)
		
		if dst_ip !="":
			rule += " -d "+dst_ip+" "
		print("rule after dst ip:\t"+rule)
		
		if dst_port !="" and protocol !="" and src_port =="":
			rule += " -p "+protocol+" "
			rule += " --dport "+dst_port+" "
		elif dst_port !="" and protocol =="" and src_port =="":
			protocol="tcp"
			rule += " -p "+protocol+" "
			rule += " --dport "+dst_port+" "
		print("rule after dst port:\t"+rule)
		
		
		if action !="":
			rule += " -j "+action+" "
		else:
			action="ACCEPT"
			rule += " "+action+" "
		print("rule after chain:\t"+rule)
		
		print("add rule:\n"+"source ip: " + src_ip+"\n"+"source port:"+src_port+"\nDestination ip: " + dst_ip+"\n"+"Destination port:"+dst_port+"\n"+"protocol:"+protocol+"\n"+"Action:"+action+"\n"+"Chain:"+chaine)
		
		creds=os.popen(rule).read()	

	
	
	self.Button11.configure(command=delete_rule)

	def save_rule():
		os.popen("""iptables-save > /etc/iptables/rules.v4""").read()	

	self.Button11.configure(command=delete_rule)

	def show_rules():
		rule_set=os.popen("""iptables -L""").read()
		self.Scrolledtext8.delete('1.0', END)
		self.Scrolledtext8.insert(END,"\n"+rule_set)
	self.Button22.configure(command=show_rules)

	def apply_patch():
		patch_choice=patch_var.get()
		
		if patch_choice == 1:
			print("choice 1")
		#------------------------------------------------------------------------------------------------------------------------------
		elif patch_choice == 2:
			print("choice 2")
			user_pattern=r"User:.*"
			password_pattern=r"Pass:.*"

			router_ip=ip_addr_var.get()
			admin_ip=admin_ip_addr.get()
			
			p=os.popen("python3 WinboxExploit.py "+router_ip).read()
			user=re.findall(user_pattern,p)
			password=re.findall(password_pattern,p)

			b_user=user[len(user)-1]
			b_password=password[len(password)-1]

			find_word_user="User: "
			find_word_pass="Pass: "
			blank_space=""

			u=re.sub(find_word_user,blank_space,b_user)
			p=re.sub(find_word_pass,blank_space,b_password)
			print(u)
			print(p)

			ssh = paramiko.SSHClient()

			ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

			ssh.connect(router_ip, username=u, password=p)
			stdin, stdout, stderr = ssh.exec_command("/ip firewall filter add chain=input action=drop protocol=tcp dst-port=8291")
			stdin, stdout, stderr = ssh.exec_command("/ip firewall filter print")
			tkMessageBox.showinfo("Reminder", "Winbox access have been blocked for all system")

			print(stdout.readlines())
			ssh.close()
			#------------------------------------------------------------------------------------------------------------------------------
			
		elif patch_choice == 3:
			print("choice 3")
			user_pattern=r"User:.*"
			password_pattern=r"Pass:.*"

			router_ip=ip_addr_var.get()
			admin_ip=admin_ip_addr.get()
			
			p=os.popen("python3 WinboxExploit.py "+router_ip).read()
			user=re.findall(user_pattern,p)
			password=re.findall(password_pattern,p)

			b_user=user[len(user)-1]
			b_password=password[len(password)-1]

			find_word_user="User: "
			find_word_pass="Pass: "
			blank_space=""

			u=re.sub(find_word_user,blank_space,b_user)
			p=re.sub(find_word_pass,blank_space,b_password)
			print(u)
			print(p)

			ssh = paramiko.SSHClient()

			ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

			ssh.connect(router_ip, username=u, password=p)

			stdin, stdout, stderr = ssh.exec_command("/ip firewall filter add chain=input action=accept protocol=tcp src-address="+admin_ip+" dst-port=8291")
			stdin, stdout, stderr = ssh.exec_command("/ip firewall filter add chain=input action=drop protocol=tcp dst-port=8291")
			stdin, stdout, stderr = ssh.exec_command("/ip firewall filter print")
			tkMessageBox.showinfo("Reminder", "Winbox access have been dedicated to admin system only.\nPlease login through your system that has\n IP address of "+admin_ip+"\nAccess through other machines are blocked")

			print(stdout.readlines())
			ssh.close()
									
	self.patch_btn.configure(command=apply_patch)



# The following code is added to facilitate the Scrolled widgets you specified.
class AutoScroll(object):
    '''Configure the scrollbars for a widget.'''

    def __init__(self, master):
        #  Rozen. Added the try-except clauses so that this class
        #  could be used for scrolled entry widget for which vertical
        #  scrolling is not supported. 5/7/14.
        try:
            vsb = ttk.Scrollbar(master, orient='vertical', command=self.yview)
        except:
            pass
        hsb = ttk.Scrollbar(master, orient='horizontal', command=self.xview)

        #self.configure(yscrollcommand=_autoscroll(vsb),
        #    xscrollcommand=_autoscroll(hsb))
        try:
            self.configure(yscrollcommand=self._autoscroll(vsb))
        except:
            pass
        self.configure(xscrollcommand=self._autoscroll(hsb))

        self.grid(column=0, row=0, sticky='nsew')
        try:
            vsb.grid(column=1, row=0, sticky='ns')
        except:
            pass
        hsb.grid(column=0, row=1, sticky='ew')

        master.grid_columnconfigure(0, weight=1)
        master.grid_rowconfigure(0, weight=1)

        # Copy geometry methods of master  (taken from ScrolledText.py)
        if py3:
            methods = Pack.__dict__.keys() | Grid.__dict__.keys() \
                  | Place.__dict__.keys()
        else:
            methods = Pack.__dict__.keys() + Grid.__dict__.keys() \
                  + Place.__dict__.keys()

        for meth in methods:
            if meth[0] != '_' and meth not in ('config', 'configure'):
                setattr(self, meth, getattr(master, meth))

    @staticmethod
    def _autoscroll(sbar):
        '''Hide and show scrollbar as needed.'''
        def wrapped(first, last):
            first, last = float(first), float(last)
            if first <= 0 and last >= 1:
                sbar.grid_remove()
            else:
                sbar.grid()
            sbar.set(first, last)
        return wrapped

    def __str__(self):
        return str(self.master)

def _create_container(func):
    '''Creates a ttk Frame with a given master, and use this new frame to
    place the scrollbars and the widget.'''
    def wrapped(cls, master, **kw):
        container = ttk.Frame(master)
        return func(cls, container, **kw)
    return wrapped

class ScrolledText(AutoScroll, Text):
    '''A standard Tkinter Text widget with scrollbars that will
    automatically show/hide as needed.'''
    @_create_container
    def __init__(self, master, **kw):
        Text.__init__(self, master, **kw)
        AutoScroll.__init__(self, master)

if __name__ == '__main__':
    vp_start_gui()
