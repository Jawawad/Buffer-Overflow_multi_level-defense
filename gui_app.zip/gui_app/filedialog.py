from Tkinter import *
import Tkinter, Tkconstants, tkFileDialog
 
root = Tk()
root.filename = tkFileDialog.askopenfilename(initialdir = "/",title = "Select file",filetypes = (("Text files","*.txt"),("all files","*.*")))
print (root.filename)
